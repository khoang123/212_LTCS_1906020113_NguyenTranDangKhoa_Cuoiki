
namespace TetrisAPI.Dtos
{
    public class TetrisReadDtos
    {
        public string NickName { get; set; }
        public int Score { get; set; }
        public DateTime LastTimePlay{get; set;}

    }
}